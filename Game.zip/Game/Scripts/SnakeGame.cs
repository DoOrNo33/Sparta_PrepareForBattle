﻿namespace Console_Scripts
{
    internal class SnakeGame
    {

        static void Main(string[] args)
        {

        }

        publ
    }
}
